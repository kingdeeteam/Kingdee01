package Dao;

public class model {
 private String ename;
 public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public String getEtype() {
	return etype;
}
public void setEtype(String etype) {
	this.etype = etype;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getElocation() {
	return elocation;
}
public void setElocation(String elocation) {
	this.elocation = elocation;
}
public String getAttribute1() {
	return attribute1;
}
public void setAttribute1(String attribute1) {
	this.attribute1 = attribute1;
}
public String getIcontent() {
	return icontent;
}
public void setIcontent(String icontent) {
	this.icontent = icontent;
}
public String getIresult() {
	return iresult;
}
public void setIresult(String iresult) {
	this.iresult = iresult;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCreation_date() {
	return creation_date;
}
public void setCreation_date(String creation_date) {
	this.creation_date = creation_date;
}
public String getName2() {
	return name2;
}
public void setName2(String name2) {
	this.name2 = name2;
}
public String getChulidate() {
	return chulidate;
}
public void setChulidate(String chulidate) {
	this.chulidate = chulidate;
}
public String getChulicuoshi() {
	return chulicuoshi;
}
public void setChulicuoshi(String chulicuoshi) {
	this.chulicuoshi = chulicuoshi;
}
public String getImageurl() {
	return imageurl;
}
public void setImageurl(String imageurl) {
	this.imageurl = imageurl;
}
private String etype;
 private String status;
 private String elocation;
 private String attribute1;
 private String icontent;
 private String iresult;
 private String name;
 private String creation_date;
 private String name2;
 private String chulidate;
 private String chulicuoshi;
 private String imageurl;
}
