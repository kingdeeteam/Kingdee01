package Service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import Dao.Model;

/**
 * Servlet implementation class Show
 */
public class Show extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Show() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String paget = request.getParameter("pagetum");
	      int pagetum = Integer.parseInt(paget);
		String page = request.getParameter("page");
	      int pageint = Integer.parseInt(page);
		String XJname = request.getParameter("XJname");
		String XJplace = request.getParameter("XJplace");
		String XJtype = request.getParameter("XJtype");
		String date01 = request.getParameter("date01");
		String date02 = request.getParameter("date02");
		System.out.println("收到了"+page+XJname+XJplace+XJtype+date01+date02);
		List<Model> models = null;
		try {
			 models = new ConnSql().listDemo(XJname,XJplace,XJtype,date01,date02,pageint,pagetum);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintWriter writer = response.getWriter();
		String json = new Gson().toJson(models);
		//System.out.println("Servlet:"+json);
		writer.write(json);
	}

}
