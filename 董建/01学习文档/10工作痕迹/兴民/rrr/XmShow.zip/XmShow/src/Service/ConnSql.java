package Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Dao.Model;

public class ConnSql {
   public List<Model> listDemo(String XJname,String XJplace,String XJtype,String date01,String date02,int pageint,int Tnum) throws ClassNotFoundException, SQLException {
	  
	   System.out.println("这是第几页"+pageint);
	   List<Model> listTest = new ArrayList<Model>();
	   int i=0;
 
	   Connection conn = null ;
	   PreparedStatement st = null ;
	   ResultSet rs = null;
	   
	   System.out.println("Downloading!!!!!");
	   int it = 0;
	   String cl_orcl = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	    String str="jdbc:sqlserver://192.168.200.2;databaseName=fhadmin";
	    String username = "sa";
	    String password = "Xm123456";

//封装字段	    
	    String str1,str2,str3;
	    if(XJtype.equals("全部")) {
	    	str1="te.ETYPE";
	    }else {
	    	str1 ="'"+XJtype+"'";
	    }
	    if(XJplace.equals("全部")) {
	    	str2="te.ENAME";
	    }else {
	    	str2 ="'"+XJplace+"'";
	    }
	    if(XJname.equals("全部")) {
	    	str3="su.name";
	    }else {
	    	str3="'"+XJname+"'";
	    }
  
	    //"-top "+pageint*Tnum+
//	    String strSql="select top "+pageint*Tnum+" te.ename 巡检点,te.ETYPE 巡检类型,te.status 状态,te.ELOCATION 巡检地点,te.ATTRIBUTE1 位置,tei.icontent 检查项目,teir.iresult 结果,su.name 巡检人姓名,teir.creation_date 检查时间,su2.name 处理人姓名,teir.chulidate 处理时间,teir.chulicuoshi 处理措施,teip.imageurl "
//	    		+ "from TB_EQUIPMENT_ITEM tei"
//	    		+"  join TB_EQUIPMENT_ITEM_RECORD teir"
//	    		 +" on tei.EQUIPMENTITEM_ID=teir.igid and teir.creation_date between '"+date01+"' and '"+date02+"'"
//	    		 +" join TB_EQUIPMENTINFO te"
//	    		+"  on te.EQUIPMENTINFO_ID=tei.EQUIPMENTINFO_ID and te.ETYPE="+str1+" and te.ENAME="+str2
//	    		+"  join sys_user su"
//	    		+"  on su.username=teir.created_by_code and su.name="+str3
//	    		 +" left join sys_user su2"
//	    		+"  on teir.chuliren=su2.username"
//	    		+"  join TB_EQUIPMENT_IMG teip"
//	    		+"  on teip.PGID=teir.gid"
//	    		+" WHERE teir.creation_date NOT IN"
//	    		+"(select top "+((pageint-1)*Tnum)+" creation_date FROM TB_EQUIPMENT_ITEM_RECORD ORDER BY creation_date) ORDER BY teir.creation_date";
		String strSql ="select * from( select *, ROW_NUMBER() OVER(order by t1.巡检点 desc) as Row from ("
						+"  select te.ename 巡检点,te.ETYPE 巡检类型,te.status 状态,te.ELOCATION 巡检地点,te.ATTRIBUTE1 位置,tei.icontent 检查项目,teir.iresult 结果,su.name 巡检人姓名,teir.creation_date 检查时间,su2.name 处理人姓名,teir.chulidate 处理时间,teir.chulicuoshi 处理措施,teip.imageurl "
						+ "from TB_EQUIPMENT_ITEM tei"
						+ " join TB_EQUIPMENT_ITEM_RECORD teir"
						+ " on tei.EQUIPMENTITEM_ID=teir.igid and teir.creation_date between '"+date01+"' and '"+date02+"'"
						 + " join TB_EQUIPMENTINFO te"
						 + " on te.EQUIPMENTINFO_ID=tei.EQUIPMENTINFO_ID and te.ETYPE="+str1+" and te.ENAME="+str2
						+ "  join sys_user su"
						+ "  on su.username=teir.created_by_code and su.name="+str3
						+ "  left join sys_user su2"
						+ "  on teir.chuliren=su2.username"
								  + " join TB_EQUIPMENT_IMG teip"
						+ "  on teip.PGID=teir.gid)  as t1"
						+ "  ) as t2"
						+ "  where t2.Row between "+((pageint-1)*Tnum+1)+" and "+pageint*Tnum;
	    
	    
	    Class.forName(cl_orcl);
			conn = DriverManager.getConnection(str,username,password);
			st = conn.prepareStatement(strSql);
			rs = st.executeQuery();
	   
	    try {
			while(rs.next()&&it<1300){
				it++;
			System.out.println(rs.getString(1).toString()+"--"+rs.getString(2)+"--"+rs.getString(3)+"--"+rs.getString(4)+"--"+rs.getString(5)+"--"+rs.getString(6)+"--"+rs.getString(7)+"--"+rs.getString(8)+"--"+rs.getString(9)+"--"+rs.getString(10)+"--"+rs.getString(11)+"--"+rs.getString(12)+"--"+rs.getString(13));
				Model mo1 = new Model();
				mo1.setEname(rs.getString(1));
				mo1.setEtype(rs.getString(2));
				mo1.setStatus(rs.getString(3));
				mo1.setElocation(rs.getString(4));
				mo1.setAttribute1(rs.getString(5));
				mo1.setIcontent(rs.getString(6));
				mo1.setIresult(rs.getString(7));
                mo1.setName(rs.getString(8));
                mo1.setCreation_date(rs.getString(9));
                mo1.setName2(rs.getString(10));
                mo1.setChulidate(rs.getString(11));
                mo1.setChulicuoshi(rs.getString(12));
                mo1.setImageurl(rs.getString(13));
				listTest.add(mo1);
			}
			System.out.println("共有多少数据："+it);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			rs.close();
			conn.close();
	
	    return listTest;
   }
}