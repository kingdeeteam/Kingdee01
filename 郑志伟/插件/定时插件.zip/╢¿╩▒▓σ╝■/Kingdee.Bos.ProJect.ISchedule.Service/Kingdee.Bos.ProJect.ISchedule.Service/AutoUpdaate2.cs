﻿using System.ComponentModel;
using Kingdee.BOS.Contracts;
using Kingdee.BOS;
using Kingdee.BOS.Core;
using Kingdee.BOS.ServiceHelper;

namespace Kingdee.Bos.ProJect.ISchedule.Service
{
    public class AutoUpdaate2 : IScheduleService
    {
        public void Run(Context ctx, Schedule schedule)
        {
            DBServiceHelper.Execute(ctx, "/*dialect*/update QRSR_t_Cust_Entry100006 set F_QRSR_TEXT='二次更新'");
        }
    }
}
